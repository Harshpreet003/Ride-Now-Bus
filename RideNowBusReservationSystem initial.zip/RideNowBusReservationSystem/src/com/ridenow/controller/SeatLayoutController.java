package com.ridenow.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ridenow.bean.SeatsBean;
import com.ridenow.model.Seats;
import com.ridenow.service.SeatLayoutService;

@Controller
public class SeatLayoutController {
	
	@Autowired
	private SeatLayoutService seatLayoutService;

	public void setSeatLayoutService(SeatLayoutService seatLayoutService) {
		this.seatLayoutService = seatLayoutService;
	}
	
	

	@RequestMapping(value="/listbuses", method = RequestMethod.GET)
	public ModelAndView listEmployees() {
		
		String busId="B11";
		System.out.println("hello");
		String doj="25/08/2018";
		Map<String, Object> model = new HashMap<String, Object>();
		
		List<SeatsBean> listSeats = new ArrayList<SeatsBean>();
		try {
			listSeats = prepareListofBean(seatLayoutService.listSeats(doj, busId));
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try
		{
			model.put("seats",  prepareListofBean(seatLayoutService.listSeats(doj, busId)));
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		System.out.println(listSeats);
		return new ModelAndView("seatlayout",model);
	}
	
	@RequestMapping(value="/calculatefare", method = RequestMethod.GET)
	public String calculateFare(Model model)
	{
		model.addAttribute("seat_no_1");
		System.out.println(model);
		return "seat";
	}
	
	private List<SeatsBean> prepareListofBean(List<Seats> seats){
		List<SeatsBean> beans = null;
		if(seats != null && !seats.isEmpty()){
			beans = new ArrayList<SeatsBean>();
			SeatsBean bean = null;
			for(Seats seat : seats){
				bean = new SeatsBean();
				bean.setDoj(seat.getDoj());
				bean.setBusid(seat.getBusid());
				bean.setSeat_no_1(seat.getSeat_no_1());
				bean.setSeat_no_2(seat.getSeat_no_2());
				bean.setSeat_no_3(seat.getSeat_no_3());
				bean.setSeat_no_4(seat.getSeat_no_4());
				bean.setSeat_no_5(seat.getSeat_no_5());
				bean.setSeat_no_6(seat.getSeat_no_6());
				bean.setSeat_no_7(seat.getSeat_no_7());
				bean.setSeat_no_8(seat.getSeat_no_8());
				bean.setSeat_no_9(seat.getSeat_no_9());
				bean.setSeat_no_10(seat.getSeat_no_10());
				bean.setSeat_no_11(seat.getSeat_no_11());
				bean.setSeat_no_12(seat.getSeat_no_12());
				bean.setSeat_no_13(seat.getSeat_no_13());
				bean.setSeat_no_14(seat.getSeat_no_14());
				bean.setSeat_no_15(seat.getSeat_no_15());
				bean.setSeat_no_16(seat.getSeat_no_16());
				bean.setSeat_no_17(seat.getSeat_no_17());
				bean.setSeat_no_18(seat.getSeat_no_18());
				bean.setSeat_no_19(seat.getSeat_no_19());
				bean.setSeat_no_20(seat.getSeat_no_20());
				bean.setSeat_no_21(seat.getSeat_no_21());
				bean.setSeat_no_22(seat.getSeat_no_22());
				bean.setSeat_no_23(seat.getSeat_no_23());
				bean.setSeat_no_24(seat.getSeat_no_24());
				bean.setSeat_no_25(seat.getSeat_no_25());
				bean.setSeat_no_26(seat.getSeat_no_26());
				bean.setSeat_no_27(seat.getSeat_no_27());
				bean.setSeat_no_28(seat.getSeat_no_28());
				bean.setSeat_no_29(seat.getSeat_no_29());
				bean.setSeat_no_30(seat.getSeat_no_30());
				beans.add(bean);
			}
		}
		return beans;
	}
	
}
