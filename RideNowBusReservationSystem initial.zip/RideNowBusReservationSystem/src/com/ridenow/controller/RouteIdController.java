package com.ridenow.controller;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ridenow.bean.Registration;
import com.ridenow.bean.UsersBean;
import com.ridenow.dao.RouteId;
import com.ridenow.model.BusDetails;
import com.ridenow.service.RouteIdService;

@Controller

public class RouteIdController {

	@Autowired
	private RouteIdService routeIdService;

	public void setRouteIdService(RouteIdService routeIdService) {
		this.routeIdService = routeIdService;
	}
	
	
	@RequestMapping(value = "/loginsuccess.html", method = RequestMethod.GET)
	public ModelAndView getSourceName(@RequestParam("source") String source,@RequestParam("destination") String destination,@RequestParam("day") String day,Model models) throws Exception 
	{
		
		Map<String, Object> model = new HashMap<String, Object>();
		System.out.println("Reached here: " + source+destination+day); 
		
		model.put("buses", routeIdService.findByRouteID(source,destination,day));
		models.addAttribute("doj",day);
		
	/*	List<BusDetails> busDetails = routeIdService.findByRouteID(source,destination,day); */
		 
		return new ModelAndView("listbuses",model);		
	}

	
	/*@RequestMapping(method = RequestMethod.POST)
		public List<BusDetails> getSourceName(@PathVariable("source") String source,@PathVariable("destination") String destination,@PathVariable("day") String day) throws Exception 
		{

			System.out.println("Reached here: " + source+destination+day); 
			List<BusDetails> busDetails = routeIdService.findByRouteID(source,destination,day); 
			 System.out.println(busDetails);
			return busDetails;		
		}
	*/
	}
     
	

