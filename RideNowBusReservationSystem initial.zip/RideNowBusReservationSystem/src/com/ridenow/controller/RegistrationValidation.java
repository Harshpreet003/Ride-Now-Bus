package com.ridenow.controller;


import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

import com.ridenow.bean.Registration;

public class RegistrationValidation {
	public boolean supports(Class<?> klass) {
		return Registration.class.isAssignableFrom(klass);
	}

	public void validate(Object target, Errors errors) {
		Registration registration = (Registration) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName",
				"NotEmpty.registration.firstName",
				"First Name must not be Empty.");
		String firstName = registration.getFirstName();
		if ((firstName.length()) > 50) {
			errors.rejectValue("firstName",
					"lengthOfUser.registration.firstName",
					"First Name must not more than 50 characters.");
		}
		
		if (!(registration.getPassword()).equals(registration
				.getConfirmPassword())) {
			errors.rejectValue("password",
					"matchingPassword.registration.password",
					"Password and Confirm Password Not match.");
		}
	}
}