package com.ridenow.dao;


public interface UserDao {
	
	public boolean checkLogin(String email, String userPassword) throws Exception;
}
