package com.ridenow.dao;

import java.util.List;

import com.ridenow.model.BusDetails;
import com.ridenow.model.BusRoute;

public interface RouteId {
	
	

	BusRoute findById(String routeId);

	BusRoute findBySourceName(String source, String destination) throws Exception;

	List<BusDetails> findById2(String routeId) throws Exception;

	List<BusDetails> findByRouteID(String source, String destination, String day) throws Exception;

}
