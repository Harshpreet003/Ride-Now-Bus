package com.ridenow.dao;


import com.ridenow.model.Users;

public interface RegistrationDao {
	public void addUsers(Users user) throws Exception;
}
