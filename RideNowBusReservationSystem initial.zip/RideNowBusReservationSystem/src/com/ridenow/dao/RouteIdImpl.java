package com.ridenow.dao;

import java.util.HashSet;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ridenow.model.BusDetails;
import com.ridenow.model.BusRoute;

public class RouteIdImpl implements RouteId {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	@Override
	public BusRoute findById(String routeId) 
	{
		Session session = sessionFactory.openSession();
		BusRoute busRoute = (BusRoute)session.get(BusRoute.class, routeId);
		session.close();
		return busRoute;
	}
	@Override
	public BusRoute findBySourceName(String source, String destination)  throws Exception {
		BusRoute busroute = null;
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from BusRoute br where br.source like :source and br.destination like :destination").setParameter("source",source).setParameter("destination",destination);
		busroute = (BusRoute) query.uniqueResult();
		session.close();
		return busroute;
	}

	@Override
	public List<BusDetails> findById2(String routeId)  throws Exception{
		List<BusDetails> busDetails=null;
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from BusDetails bd where bd.routeId like :routeId ").setParameter("routeId", "%"+routeId+"%");
		busDetails=query.list();
		session.close();
		return busDetails;
	}
	
	@Override
	public List<BusDetails> findByRouteID(String source, String destination, String day) throws Exception
	{
		List<BusDetails> busdetails = null;
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from BusDetails bd where bd.routeId in(select br.routeId from BusRoute br where br.source like :source and br.destination like :destination)");
		query.setParameter("source", source );
		query.setParameter("destination", destination);
		/*query.setParameter("day", day);*/
		busdetails = query.list();
		session.close();
		return busdetails;

	}

}
