package com.ridenow.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "seat_details")
public class Seats {
	
	
	@Id
	@Column(name="bus_id")
	String busid;

	@Column(name="date_of_journey")
	String doj;
	@Column(name="seat_no_1")
	int seat_no_1;
	@Column(name="seat_no_2")
	int seat_no_2;
	@Column(name="seat_no_3")
	int seat_no_3;
	@Column(name="seat_no_4")
	int seat_no_4;
	@Column(name="seat_no_5")
	int seat_no_5;
	@Column(name="seat_no_6")
	int seat_no_6;
	@Column(name="seat_no_7")
	int seat_no_7;
	@Column(name="seat_no_8")
	int seat_no_8;
	@Column(name="seat_no_9")
	int seat_no_9;
	@Column(name="seat_no_10")
	int seat_no_10;
	@Column(name="seat_no_11")
	int seat_no_11;
	@Column(name="seat_no_12")
	int seat_no_12;
	@Column(name="seat_no_13")
	int seat_no_13;
	@Column(name="seat_no_14")
	int seat_no_14;
	@Column(name="seat_no_15")
	int seat_no_15;
	@Column(name="seat_no_16")
	int seat_no_16;
	@Column(name="seat_no_17")
	int seat_no_17;
	@Column(name="seat_no_18")
	int seat_no_18;
	@Column(name="seat_no_19")
	int seat_no_19;
	@Column(name="seat_no_20")
	int seat_no_20;
	@Column(name="seat_no_21")
	int seat_no_21;
	@Column(name="seat_no_22")
	int seat_no_22;
	@Column(name="seat_no_23")
	int seat_no_23;
	@Column(name="seat_no_24")
	int seat_no_24;
	@Column(name="seat_no_25")
	int seat_no_25;
	@Column(name="seat_no_26")
	int seat_no_26;
	@Column(name="seat_no_27")
	int seat_no_27;
	@Column(name="seat_no_28")
	int seat_no_28;
	@Column(name="seat_no_29")
	int seat_no_29;
	@Column(name="seat_no_30")
	int seat_no_30;
	
	public int getSeat_no_1() {
		return seat_no_1;
	}
	public void setSeat_no_1(int seat_no_1) {
		this.seat_no_1 = seat_no_1;
	}
	public int getSeat_no_2() {
		return seat_no_2;
	}
	public void setSeat_no_2(int seat_no_2) {
		this.seat_no_2 = seat_no_2;
	}
	public int getSeat_no_3() {
		return seat_no_3;
	}
	public void setSeat_no_3(int seat_no_3) {
		this.seat_no_3 = seat_no_3;
	}
	public int getSeat_no_4() {
		return seat_no_4;
	}
	public void setSeat_no_4(int seat_no_4) {
		this.seat_no_4 = seat_no_4;
	}
	public int getSeat_no_5() {
		return seat_no_5;
	}
	public void setSeat_no_5(int seat_no_5) {
		this.seat_no_5 = seat_no_5;
	}
	public int getSeat_no_6() {
		return seat_no_6;
	}
	public void setSeat_no_6(int seat_no_6) {
		this.seat_no_6 = seat_no_6;
	}
	public int getSeat_no_7() {
		return seat_no_7;
	}
	public void setSeat_no_7(int seat_no_7) {
		this.seat_no_7 = seat_no_7;
	}
	public int getSeat_no_8() {
		return seat_no_8;
	}
	public void setSeat_no_8(int seat_no_8) {
		this.seat_no_8 = seat_no_8;
	}
	public int getSeat_no_9() {
		return seat_no_9;
	}
	public void setSeat_no_9(int seat_no_9) {
		this.seat_no_9 = seat_no_9;
	}
	public int getSeat_no_10() {
		return seat_no_10;
	}
	public void setSeat_no_10(int seat_no_10) {
		this.seat_no_10 = seat_no_10;
	}
	public int getSeat_no_11() {
		return seat_no_11;
	}
	public void setSeat_no_11(int seat_no_11) {
		this.seat_no_11 = seat_no_11;
	}
	public int getSeat_no_12() {
		return seat_no_12;
	}
	public void setSeat_no_12(int seat_no_12) {
		this.seat_no_12 = seat_no_12;
	}
	public int getSeat_no_13() {
		return seat_no_13;
	}
	public void setSeat_no_13(int seat_no_13) {
		this.seat_no_13 = seat_no_13;
	}
	public int getSeat_no_14() {
		return seat_no_14;
	}
	public void setSeat_no_14(int seat_no_14) {
		this.seat_no_14 = seat_no_14;
	}
	public int getSeat_no_15() {
		return seat_no_15;
	}
	public void setSeat_no_15(int seat_no_15) {
		this.seat_no_15 = seat_no_15;
	}
	public int getSeat_no_16() {
		return seat_no_16;
	}
	public void setSeat_no_16(int seat_no_16) {
		this.seat_no_16 = seat_no_16;
	}
	public int getSeat_no_17() {
		return seat_no_17;
	}
	public void setSeat_no_17(int seat_no_17) {
		this.seat_no_17 = seat_no_17;
	}
	public int getSeat_no_18() {
		return seat_no_18;
	}
	public void setSeat_no_18(int seat_no_18) {
		this.seat_no_18 = seat_no_18;
	}
	public int getSeat_no_19() {
		return seat_no_19;
	}
	public void setSeat_no_19(int seat_no_19) {
		this.seat_no_19 = seat_no_19;
	}
	public int getSeat_no_20() {
		return seat_no_20;
	}
	public void setSeat_no_20(int seat_no_20) {
		this.seat_no_20 = seat_no_20;
	}
	public int getSeat_no_21() {
		return seat_no_21;
	}
	public void setSeat_no_21(int seat_no_21) {
		this.seat_no_21 = seat_no_21;
	}
	public int getSeat_no_22() {
		return seat_no_22;
	}
	public void setSeat_no_22(int seat_no_22) {
		this.seat_no_22 = seat_no_22;
	}
	public int getSeat_no_23() {
		return seat_no_23;
	}
	public void setSeat_no_23(int seat_no_23) {
		this.seat_no_23 = seat_no_23;
	}
	public int getSeat_no_24() {
		return seat_no_24;
	}
	public void setSeat_no_24(int seat_no_24) {
		this.seat_no_24 = seat_no_24;
	}
	public int getSeat_no_25() {
		return seat_no_25;
	}
	public void setSeat_no_25(int seat_no_25) {
		this.seat_no_25 = seat_no_25;
	}
	public int getSeat_no_26() {
		return seat_no_26;
	}
	public void setSeat_no_26(int seat_no_26) {
		this.seat_no_26 = seat_no_26;
	}
	public int getSeat_no_27() {
		return seat_no_27;
	}
	public void setSeat_no_27(int seat_no_27) {
		this.seat_no_27 = seat_no_27;
	}
	public int getSeat_no_28() {
		return seat_no_28;
	}
	public void setSeat_no_28(int seat_no_28) {
		this.seat_no_28 = seat_no_28;
	}
	public int getSeat_no_29() {
		return seat_no_29;
	}
	public void setSeat_no_29(int seat_no_29) {
		this.seat_no_29 = seat_no_29;
	}
	public int getSeat_no_30() {
		return seat_no_30;
	}
	public void setSeat_no_30(int seat_no_30) {
		this.seat_no_30 = seat_no_30;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public String getBusid() {
		return busid;
	}
	public void setBusid(String busid) {
		this.busid = busid;
	}
	@Override
	public String toString() {
		return "Seats [busid=" + busid + ", doj=" + doj + ", seat_no_1=" + seat_no_1 + ", seat_no_2=" + seat_no_2
				+ ", seat_no_3=" + seat_no_3 + ", seat_no_4=" + seat_no_4 + ", seat_no_5=" + seat_no_5 + ", seat_no_6="
				+ seat_no_6 + ", seat_no_7=" + seat_no_7 + ", seat_no_8=" + seat_no_8 + ", seat_no_9=" + seat_no_9
				+ ", seat_no_10=" + seat_no_10 + ", seat_no_11=" + seat_no_11 + ", seat_no_12=" + seat_no_12
				+ ", seat_no_13=" + seat_no_13 + ", seat_no_14=" + seat_no_14 + ", seat_no_15=" + seat_no_15
				+ ", seat_no_16=" + seat_no_16 + ", seat_no_17=" + seat_no_17 + ", seat_no_18=" + seat_no_18
				+ ", seat_no_19=" + seat_no_19 + ", seat_no_20=" + seat_no_20 + ", seat_no_21=" + seat_no_21
				+ ", seat_no_22=" + seat_no_22 + ", seat_no_23=" + seat_no_23 + ", seat_no_24=" + seat_no_24
				+ ", seat_no_25=" + seat_no_25 + ", seat_no_26=" + seat_no_26 + ", seat_no_27=" + seat_no_27
				+ ", seat_no_28=" + seat_no_28 + ", seat_no_29=" + seat_no_29 + ", seat_no_30=" + seat_no_30 + "]";
	}
	
	
	
	
}
