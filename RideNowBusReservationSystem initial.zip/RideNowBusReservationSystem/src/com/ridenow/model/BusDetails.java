package com.ridenow.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bus_detailss")
public class BusDetails implements Serializable{

	@Id
	@Column(name="bus_id")
	private int busId;

	@Column(name="route_id")
	private int routeId;
	
	@Column(name="bus_number")
	private String busNumber;
	
	@Column(name="bus_Name")
	private String busName;
	
	@Column(name="bus_type")
	private String busType;
	
	@Column(name="bus_capacity")
	private String busCapacity;
	
	@Column(name="departure_time")
	private String departureTime;
	
	@Column(name="arrival_time")
	private String arrivalTime;
	
	@Column(name="fare")
	private int fare;

	public int getBusId() {
		return busId;
	}

	

	public void setBusId(int busId) {
		this.busId = busId;
	}



	

	public int getRouteId() {
		return routeId;
	}



	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}



	public String getBusNumber() {
		return busNumber;
	}

	public void setBusNumber(String busNumber) {
		this.busNumber = busNumber;
	}

	public String getBusName() {
		return busName;
	}

	public void setBusName(String busName) {
		this.busName = busName;
	}

	public String getBusType() {
		return busType;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public String getBusCapacity() {
		return busCapacity;
	}

	public void setBusCapacity(String busCapacity) {
		this.busCapacity = busCapacity;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public int getFare() {
		return fare;
	}

	public void setFare(int fare) {
		this.fare = fare;
	}



	@Override
	public String toString() {
		return "BusDetails [busId=" + busId + ", routeId=" + routeId + ", busNumber=" + busNumber + ", busName="
				+ busName + ", busType=" + busType + ", busCapacity=" + busCapacity + ", departureTime=" + departureTime
				+ ", arrivalTime=" + arrivalTime + ", fare=" + fare + "]";
	}
	
	
}
