package com.ridenow.service;

import java.util.HashSet;
import java.util.List;

import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ridenow.dao.RouteIdImpl;
import com.ridenow.model.BusDetails;
import com.ridenow.model.BusRoute;

@Service("routeIdService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class RouteIdServiceImpl implements RouteIdService{

	@Autowired
	private RouteIdImpl routeIdImpl;
	
	
	public RouteIdImpl getRouteIdImpl() {
		return routeIdImpl;
	}
	


	public void setRouteIdImpl(RouteIdImpl routeIdImpl) {
		this.routeIdImpl = routeIdImpl;
	}


	@Override
	public BusRoute findById(String routeId) throws Exception{
		
		return routeIdImpl.findById(routeId);
	}

	@Override
	public BusRoute findBySourceName(String source, String destination) throws Exception{
		
		return routeIdImpl.findBySourceName(source, destination);
	}

	@Override
	public List<BusDetails> findById2(String routeId) throws Exception{
		
		return routeIdImpl.findById2(routeId);
	}

	@Override
	public List<BusDetails> findByRouteID(String source, String destination, String day) throws Exception{
	
		return routeIdImpl.findByRouteID(source, destination, day);
	}
	
}
