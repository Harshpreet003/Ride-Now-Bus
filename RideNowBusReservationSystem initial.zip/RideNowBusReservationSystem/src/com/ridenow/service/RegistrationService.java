package com.ridenow.service;


import com.ridenow.model.Users;

public interface RegistrationService {
	public void addUsers(Users user) throws Exception;
}
