package com.ridenow.service;


public interface UserService {
	public boolean checkLogin(String email, String userPassword) throws Exception;
}
