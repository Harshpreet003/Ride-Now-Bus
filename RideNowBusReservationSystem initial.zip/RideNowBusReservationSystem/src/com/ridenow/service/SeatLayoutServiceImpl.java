package com.ridenow.service;

import java.util.List;

import com.ridenow.dao.SeatLayoutDaoImpl;
import com.ridenow.model.Seats;

public class SeatLayoutServiceImpl implements SeatLayoutService {

	private SeatLayoutDaoImpl seatLayoutDaoImpl;
	
	
	public SeatLayoutDaoImpl getSeatLayoutDaoImpl() {
		return seatLayoutDaoImpl;
	}


	public void setSeatLayoutDaoImpl(SeatLayoutDaoImpl seatLayoutDaoImpl) {
		this.seatLayoutDaoImpl = seatLayoutDaoImpl;
	}


	@Override
	public List<Seats> listSeats(String doj, String busid) throws Exception {

		
		
		return seatLayoutDaoImpl.listSeats(doj, busid);
	}

}
