package com.ridenow.service;

import java.util.List;

import com.ridenow.model.BusDetails;
import com.ridenow.model.BusRoute;

public interface RouteIdService {
	
	
	BusRoute findById(String routeId) throws Exception;

	BusRoute findBySourceName(String source, String destination) throws Exception;

	List<BusDetails> findById2(String routeId) throws Exception;

	List<BusDetails> findByRouteID(String source, String destination, String day) throws Exception;

}
