package com.ridenow.dao;

import java.util.List;

import com.ridenow.model.Seats;

public interface SeatLayoutDao  {

	public List<Seats> listSeats(String doj,String busid) throws Exception;
	
}
