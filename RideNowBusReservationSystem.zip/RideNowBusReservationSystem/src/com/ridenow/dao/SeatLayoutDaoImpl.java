package com.ridenow.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.ridenow.model.Seats;

public class SeatLayoutDaoImpl implements SeatLayoutDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}



	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}



	@Override
	public List<Seats> listSeats(String doj,String busid) throws Exception {


		List<Seats> listseats=null;
		Session session = sessionFactory.openSession();
		String SQL_QUERY ="from Seats as sd where sd.doj =? and busid = ? ";
		Query query = session.createQuery(SQL_QUERY);
		query.setParameter(0,doj);
		query.setParameter(1,busid);
		listseats = query.list();
		return listseats;
		/*as b where b.data_of_journey=? and b.bus_id=?*/
	}

}
